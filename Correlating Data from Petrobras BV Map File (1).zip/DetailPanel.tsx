import React from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Entity {
  id: string;
  name: string;
  kvk: string;
  address: string;
  type: string;
  category: string;
  description: string;
}

interface DetailPanelProps {
  entity: Entity;
  onClose: () => void;
}

export function DetailPanel({ entity, onClose }: DetailPanelProps) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Petrobras-linked':
        return 'bg-yellow-900/30 border-yellow-700/50 text-yellow-200';
      case 'Upstream/Offshore':
        return 'bg-blue-900/30 border-blue-700/50 text-blue-200';
      case 'Vendor/Service':
        return 'bg-purple-900/30 border-purple-700/50 text-purple-200';
      default:
        return 'bg-slate-900/30 border-slate-700/50 text-slate-200';
    }
  };

  return (
    <div className="fixed inset-0 z-50 pointer-events-none">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm pointer-events-auto"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="absolute right-0 top-0 bottom-0 w-96 bg-card border-l border-border shadow-2xl pointer-events-auto overflow-y-auto animate-in slide-in-from-right-96 duration-300">
        <div className="p-6">
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 hover:bg-secondary rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-foreground" />
          </button>

          {/* Entity Name */}
          <h2 className="text-xl font-mono font-bold text-primary mb-2 pr-8">
            {entity.name}
          </h2>

          {/* Category Badge */}
          <div className={`inline-block px-3 py-1 rounded-full text-xs font-mono font-bold border mb-6 ${getCategoryColor(entity.category)}`}>
            {entity.category}
          </div>

          {/* Description */}
          <div className="mb-6">
            <h3 className="text-sm font-mono font-bold text-muted-foreground mb-2">
              DESCRIPTION
            </h3>
            <p className="text-sm text-foreground">
              {entity.description}
            </p>
          </div>

          {/* KVK Information */}
          <div className="space-y-4 mb-6">
            <div>
              <h3 className="text-sm font-mono font-bold text-muted-foreground mb-1">
                KVK NUMBER
              </h3>
              <p className="text-base font-mono text-primary">
                {entity.kvk !== 'Unknown' ? entity.kvk : 'Not yet registered'}
              </p>
            </div>

            <div>
              <h3 className="text-sm font-mono font-bold text-muted-foreground mb-1">
                ENTITY TYPE
              </h3>
              <p className="text-sm text-foreground">
                {entity.type}
              </p>
            </div>

            <div>
              <h3 className="text-sm font-mono font-bold text-muted-foreground mb-1">
                ADDRESS
              </h3>
              <p className="text-sm text-foreground">
                {entity.address}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2">
            {entity.kvk !== 'Unknown' && (
              <Button
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-mono"
                onClick={() => {
                  window.open(
                    `https://www.kvk.nl/en/search/?q=${encodeURIComponent(entity.name)}`,
                    '_blank'
                  );
                }}
              >
                View on KVK
              </Button>
            )}
            <Button
              variant="outline"
              className="w-full font-mono"
              onClick={onClose}
            >
              Close
            </Button>
          </div>

          {/* Footer Note */}
          <div className="mt-6 p-3 bg-secondary/50 rounded-lg border border-border">
            <p className="text-xs text-muted-foreground">
              This is a study case tracking Petrobras-linked B.V. entities. Evidence labels distinguish confirmed, partial, and unresolved relationships.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
