# Petrobras B.V. Entity Correlation Analysis Report

This report analyzes the correlation between Petrobras's corporate ecosystem and its contractual relationships with B.V. (Besloten Vennootschap) entities, based on the provided dataset and the Petrobras B.V. Map project.

## Executive Summary

The analysis identifies a significant concentration of contractual value within a few key B.V. entities. **Petrobras Netherlands B.V.** stands out as the primary vehicle for high-value offshore contracts, followed by specialized field-specific entities like **Roncador B.V.** and **Tupi B.V.**

### Key Findings

| Entity Name | Total Contract Value (USD/EUR) | Contract Count | Primary Role |
| :--- | :--- | :--- | :--- |
| Petrobras Netherlands B.V. | ~37.76 Billion | 1,864 | Central Hub / Operations |
| Roncador B.V. | ~9.88 Billion | 291 | Field-Specific (Roncador) |
| Tupi B.V. | ~9.42 Billion | 769 | Field-Specific (Tupi) |
| Tamandare B.V. | ~6.41 Billion | 1 | Asset-Specific |
| Buzios5 MV32 B.V. | ~5.85 Billion | 1 | Asset-Specific (FPSO) |

## Data Correlations

### 1. Value vs. Volume Concentration
The correlation between the number of contracts and total value shows two distinct patterns:
- **Hub Entities:** High volume and high value (e.g., Petrobras Netherlands B.V.). These act as the operational backbone.
- **Strategic Asset Vehicles:** Low volume (often a single contract) but extremely high value (billions). These typically represent major infrastructure like FPSOs or specific field developments.

### 2. Contract Situations
The majority of high-value contracts are currently in "Concluído" (Completed) or "Ativo" (Active) status. However, a significant number of smaller service contracts are associated with the hub entities, indicating a complex web of ongoing operational support.

### 3. Temporal Trends
Contract activity shows peaks corresponding to major offshore field development phases. The data indicates a steady stream of smaller operational contracts punctuated by massive capital expenditure agreements for new production units.

## Visualizations

- **Top B.V. Entities by Value:** Highlights the financial dominance of specific vehicles.
- **Contract Count vs. Value:** Illustrates the strategic difference between operational hubs and asset-specific vehicles.
- **Situation Heatmap:** Shows the lifecycle of contracts across different entities.
- **Time Series Analysis:** Tracks the evolution of contractual commitments.

## Conclusion

The Petrobras B.V. ecosystem is structured to isolate major asset risks and financing into specific vehicles while maintaining a centralized operational hub in the Netherlands. This correlation suggests a highly optimized corporate structure for managing international offshore operations and large-scale capital investments.
