import pandas as pd
import json
import re

def clean_value(val):
    if pd.isna(val):
        return 0.0
    val = str(val).replace('US$', '').replace('EUR', '').replace('GBP', '').strip()
    if ',' in val and '.' in val:
        val = val.replace('.', '').replace(',', '.')
    elif ',' in val:
        val = val.replace(',', '.')
    
    try:
        return float(val)
    except:
        return 0.0

# Load the CSV with on_bad_lines='skip' to handle inconsistent rows
try:
    df = pd.read_csv('/home/ubuntu/upload/Consulta(17).csv', sep=';', encoding='utf-8-sig', on_bad_lines='skip')
except Exception as e:
    print(f"Error reading with utf-8-sig: {e}")
    df = pd.read_csv('/home/ubuntu/upload/Consulta(17).csv', sep=';', encoding='latin1', on_bad_lines='skip')

# Clean numeric columns
df['Valor do contrato'] = df['Valor do contrato'].apply(clean_value)

# Extract unique vendors and their total contract values
vendors = df.groupby('Fornecedor').agg({
    'Valor do contrato': 'sum',
    'Objeto da contratação': 'count'
}).reset_index()

vendors.columns = ['name', 'total_value', 'contract_count']

# Filter for B.V. entities
bv_vendors = vendors[vendors['name'].str.contains('B.V.', na=False)].copy()

# Sort by total value
bv_vendors = bv_vendors.sort_values(by='total_value', ascending=False)

# Save the analysis result
bv_vendors.to_csv('/home/ubuntu/bv_vendors_analysis.csv', index=False)

print(f"Found {len(bv_vendors)} B.V. entities.")
print(bv_vendors.head(10))

# Save top 20 for visualization
top_bv = bv_vendors.head(20)

# Create a summary of contracts for these top B.V.s
top_bv_names = top_bv['name'].tolist()
contracts_summary = df[df['Fornecedor'].isin(top_bv_names)]
contracts_summary.to_csv('/home/ubuntu/top_bv_contracts.csv', index=False)
