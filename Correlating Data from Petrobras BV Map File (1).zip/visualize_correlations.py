import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Load the analyzed data
bv_vendors = pd.read_csv('/home/ubuntu/bv_vendors_analysis.csv')

# Set style
plt.style.use('dark_background')
plt.rcParams['figure.facecolor'] = '#121212'
plt.rcParams['axes.facecolor'] = '#121212'

# 1. Bar chart of Top 15 B.V. Entities by Contract Value
plt.figure(figsize=(12, 8))
top_15 = bv_vendors.head(15)
sns.barplot(data=top_15, x='total_value', y='name', hue='name', palette='viridis', legend=False)
plt.title('Top 15 B.V. Entities by Total Contract Value', fontsize=16, color='#00d4ff')
plt.xlabel('Total Value (USD/EUR)', fontsize=12)
plt.ylabel('B.V. Entity Name', fontsize=12)
plt.tight_layout()
plt.savefig('/home/ubuntu/top_bv_values.png')
plt.close()

# 2. Scatter plot: Contract Count vs Total Value
plt.figure(figsize=(10, 6))
sns.scatterplot(data=bv_vendors, x='contract_count', y='total_value', size='total_value', sizes=(50, 500), alpha=0.6, color='#ffaa00')
plt.yscale('log')
plt.xscale('log')
plt.title('Contract Count vs. Total Value (Log Scale)', fontsize=16, color='#00d4ff')
plt.xlabel('Number of Contracts', fontsize=12)
plt.ylabel('Total Value', fontsize=12)
plt.grid(True, which="both", ls="-", alpha=0.2)
plt.tight_layout()
plt.savefig('/home/ubuntu/count_vs_value.png')
plt.close()

# 3. Distribution of Contract Values
plt.figure(figsize=(10, 6))
sns.histplot(bv_vendors['total_value'], bins=20, kde=True, color='#00ff88')
plt.xscale('log')
plt.title('Distribution of Total Contract Values', fontsize=16, color='#00d4ff')
plt.xlabel('Total Value (Log Scale)', fontsize=12)
plt.ylabel('Frequency', fontsize=12)
plt.tight_layout()
plt.savefig('/home/ubuntu/value_distribution.png')
plt.close()

print("Visualizations generated successfully.")
