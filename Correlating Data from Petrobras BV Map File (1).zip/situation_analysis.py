import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the full contract data for top B.V.s
df = pd.read_csv('/home/ubuntu/top_bv_contracts.csv')

# Create a pivot table of B.V. Entity vs Situation
pivot_df = df.groupby(['Fornecedor', 'Situação']).size().unstack(fill_value=0)

# Sort by total contracts
pivot_df['Total'] = pivot_df.sum(axis=1)
pivot_df = pivot_df.sort_values('Total', ascending=False).drop('Total', axis=1).head(15)

# Plot heatmap
plt.figure(figsize=(14, 10))
plt.style.use('dark_background')
plt.rcParams['figure.facecolor'] = '#121212'
plt.rcParams['axes.facecolor'] = '#121212'

sns.heatmap(pivot_df, annot=True, fmt='d', cmap='YlGnBu', cbar_kws={'label': 'Number of Contracts'})
plt.title('Contract Situations for Top 15 B.V. Entities', fontsize=18, color='#00d4ff', pad=20)
plt.xlabel('Contract Situation', fontsize=14)
plt.ylabel('B.V. Entity Name', fontsize=14)
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.savefig('/home/ubuntu/situation_heatmap.png')
plt.close()

print("Situation heatmap generated.")
