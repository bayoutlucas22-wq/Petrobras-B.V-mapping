import pandas as pd
import matplotlib.pyplot as plt

# Load the full contract data for top B.V.s
df = pd.read_csv('/home/ubuntu/top_bv_contracts.csv')

# Convert dates to datetime objects
df['Início da vigência'] = pd.to_datetime(df['Início da vigência'], format='%d/%m/%Y', errors='coerce')

# Drop rows with invalid dates
df = df.dropna(subset=['Início da vigência'])

# Extract year-month
df['YearMonth'] = df['Início da vigência'].dt.to_period('M')

# Group by month and count contracts
time_series = df.groupby('YearMonth').size()

# Plot
plt.figure(figsize=(15, 7))
plt.style.use('dark_background')
plt.rcParams['figure.facecolor'] = '#121212'
plt.rcParams['axes.facecolor'] = '#121212'

time_series.plot(kind='line', marker='o', color='#00d4ff', linewidth=2)
plt.title('Contract Activity Over Time (Start Date)', fontsize=18, color='#00d4ff')
plt.xlabel('Month', fontsize=14)
plt.ylabel('Number of New Contracts', fontsize=14)
plt.grid(True, alpha=0.2)
plt.tight_layout()
plt.savefig('/home/ubuntu/time_series.png')
plt.close()

print("Time series plot generated.")
