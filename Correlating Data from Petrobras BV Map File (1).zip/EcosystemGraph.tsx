import React, { useCallback, useState, useMemo } from 'react';
import ReactFlow, {
  Node,
  Edge,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  Position,
} from 'reactflow';
import 'reactflow/dist/style.css';
import entities from '@/data/kvk-entities.json';
import { EntityNode } from './EntityNode';
import { DetailPanel } from './DetailPanel';

const nodeTypes = {
  entity: EntityNode,
} as const;

export function EcosystemGraph() {
  const [selectedEntity, setSelectedEntity] = useState<typeof entities[0] | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<string | 'all'>('all');

  // Generate nodes with force-directed layout clustering
  const { nodes: initialNodes, edges: initialEdges } = useMemo(() => {
    const nodes: Node[] = [];
    const edges: Edge[] = [];
    
    // Categorize entities
    const petrobrasEntities = entities.filter(e => e.category === 'Petrobras-linked');
    const upstreamEntities = entities.filter(e => e.category === 'Upstream/Offshore');
    const vendorEntities = entities.filter(e => e.category === 'Vendor/Service');

    // Center node for Petrobras
    const centerX = 0;
    const centerY = 0;
    const centerRadius = 80;

    // Add Petrobras-linked entities in inner circle
    petrobrasEntities.forEach((entity, idx) => {
      const angle = (idx / petrobrasEntities.length) * Math.PI * 2;
      const x = centerX + Math.cos(angle) * centerRadius;
      const y = centerY + Math.sin(angle) * centerRadius;

      nodes.push({
        id: entity.id,
        data: { label: entity.name, entity },
        position: { x, y },
        type: 'entity',
        style: {
          background: 'oklch(0.45 0.15 265)',
          border: '2px solid oklch(0.55 0.20 200)',
          borderRadius: '8px',
          padding: '8px',
          color: 'oklch(0.90 0.01 265)',
          fontSize: '12px',
          fontWeight: 600,
          fontFamily: "'IBM Plex Mono', monospace",
          width: '120px',
          textAlign: 'center',
          boxShadow: '0 0 20px oklch(0.55 0.20 200 / 0.6)',
          cursor: 'pointer',
          transition: 'all 0.2s ease-out',
        },
      });
    });

    // Add upstream/offshore entities in middle rings
    const upstreamRadius = 200;
    upstreamEntities.forEach((entity, idx) => {
      const angle = (idx / upstreamEntities.length) * Math.PI * 2;
      const x = centerX + Math.cos(angle) * upstreamRadius;
      const y = centerY + Math.sin(angle) * upstreamRadius;

      nodes.push({
        id: entity.id,
        data: { label: entity.name, entity },
        position: { x, y },
        type: 'entity',
        style: {
          background: 'oklch(0.45 0.15 265)',
          border: '2px solid oklch(0.55 0.20 200)',
          borderRadius: '8px',
          padding: '8px',
          color: 'oklch(0.90 0.01 265)',
          fontSize: '11px',
          fontWeight: 600,
          fontFamily: "'IBM Plex Mono', monospace",
          width: '110px',
          textAlign: 'center',
          boxShadow: '0 0 15px oklch(0.55 0.20 200 / 0.4)',
          cursor: 'pointer',
          transition: 'all 0.2s ease-out',
        },
      });
    });

    // Add vendor/service entities in outer ring
    const vendorRadius = 320;
    vendorEntities.forEach((entity, idx) => {
      const angle = (idx / vendorEntities.length) * Math.PI * 2;
      const x = centerX + Math.cos(angle) * vendorRadius;
      const y = centerY + Math.sin(angle) * vendorRadius;

      nodes.push({
        id: entity.id,
        data: { label: entity.name, entity },
        position: { x, y },
        type: 'entity',
        style: {
          background: 'oklch(0.45 0.15 265)',
          border: '2px solid oklch(0.50 0.12 280)',
          borderRadius: '8px',
          padding: '6px',
          color: 'oklch(0.90 0.01 265)',
          fontSize: '10px',
          fontWeight: 600,
          fontFamily: "'IBM Plex Mono', monospace",
          width: '100px',
          textAlign: 'center',
          boxShadow: '0 0 10px oklch(0.50 0.12 280 / 0.3)',
          cursor: 'pointer',
          transition: 'all 0.2s ease-out',
        },
      });
    });

    // Create edges connecting Petrobras entities to others
    petrobrasEntities.forEach(petrobras => {
      // Connect to some upstream entities (simplified for demo)
      upstreamEntities.slice(0, 5).forEach(upstream => {
        edges.push({
          id: `${petrobras.id}-${upstream.id}`,
          source: petrobras.id,
          target: upstream.id,
          style: {
            stroke: 'oklch(0.55 0.20 200 / 0.3)',
            strokeWidth: 1.5,
          },
          animated: true,
        });
      });
    });

    return { nodes, edges };
  }, []);

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  // Filter nodes based on search and category
  const filteredNodes = useMemo(() => {
    return nodes.map(node => {
      const entity = node.data?.entity;
      if (!entity) return node;

      const matchesSearch = searchTerm === '' || 
        entity.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = filterCategory === 'all' || 
        entity.category === filterCategory;

      const isVisible = matchesSearch && matchesCategory;

      const updatedNode = {
        ...node,
        style: {
          ...node.style,
          opacity: isVisible ? 1 : 0.2,
          pointerEvents: (isVisible ? 'auto' : 'none') as any,
        },
      };
      return updatedNode as Node;
    });
  }, [nodes, searchTerm, filterCategory]);

  const handleNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    const entity = node.data?.entity;
    if (entity) {
      setSelectedEntity(entity);
    }
  }, []);

  return (
    <div className="w-full h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border p-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-primary mb-4">
            Petrobras B.V. Ecosystem
          </h1>
          <div className="flex gap-4">
            <input
              type="text"
              placeholder="Search entities..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 px-3 py-2 bg-secondary text-foreground border border-border rounded-md text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="px-3 py-2 bg-secondary text-foreground border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="all">All Categories</option>
              <option value="Petrobras-linked">Petrobras-linked</option>
              <option value="Upstream/Offshore">Upstream/Offshore</option>
              <option value="Vendor/Service">Vendor/Service</option>
            </select>
          </div>
        </div>
      </div>

      {/* Graph Container */}
      <div className="flex-1 relative">
        <ReactFlow
          nodes={filteredNodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          nodeTypes={nodeTypes}
          onNodeClick={handleNodeClick}
          fitView
        >
          <Background color="oklch(0.15 0.02 265)" gap={16} />
          <Controls />
        </ReactFlow>

        {/* Detail Panel */}
        {selectedEntity && (
          <DetailPanel
            entity={selectedEntity}
            onClose={() => setSelectedEntity(null)}
          />
        )}
      </div>
    </div>
  );
}
