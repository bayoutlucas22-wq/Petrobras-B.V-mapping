import React from 'react';
import { Handle, Position } from 'reactflow';

interface EntityNodeProps {
  data: {
    label: string;
    entity: any;
  };
  isConnecting?: boolean;
  selected?: boolean;
}

export function EntityNode({ data, selected }: EntityNodeProps) {
  const { entity } = data;
  
  // Color based on category
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Petrobras-linked':
        return 'oklch(0.65 0.18 50)'; // Amber
      case 'Upstream/Offshore':
        return 'oklch(0.55 0.20 200)'; // Cyan
      case 'Vendor/Service':
        return 'oklch(0.50 0.12 280)'; // Purple
      default:
        return 'oklch(0.45 0.15 265)'; // Slate blue
    }
  };

  const categoryColor = getCategoryColor(entity.category);

  return (
    <div
      className="px-3 py-2 rounded-lg border-2 transition-all duration-200"
      style={{
        background: 'oklch(0.15 0.02 265)',
        borderColor: categoryColor,
        boxShadow: selected
          ? `0 0 24px ${categoryColor}, inset 0 0 12px ${categoryColor}`
          : `0 0 12px ${categoryColor}`,
        color: 'oklch(0.90 0.01 265)',
      }}
    >
      <Handle type="target" position={Position.Top} />
      <div className="text-xs font-mono font-bold text-center whitespace-nowrap overflow-hidden text-ellipsis">
        {entity.name}
      </div>
      <Handle type="source" position={Position.Bottom} />
    </div>
  );
}
