# Petrobras B.V. Ecosystem Visualizer – Design Brainstorm

## Three Stylistic Approaches

### 1. **Industrial Network Atlas**
A dark, technical aesthetic inspired by infrastructure blueprints and industrial schematics. Nodes glow with energy, edges pulse with data flow. Probability: 0.04

### 2. **Organic Ecosystem Web**
A living, breathing network with soft gradients, flowing curves, and nature-inspired colors (ocean blues, earth tones). Nodes feel like organisms connected by symbiotic relationships. Probability: 0.07

### 3. **Corporate Intelligence Dashboard**
A clean, professional interface with sharp lines, corporate blues, and a focus on data clarity. Resembles financial trading floors or enterprise software. Probability: 0.02

---

## Selected Approach: **Industrial Network Atlas**

This approach reflects the technical, infrastructure-heavy nature of Petrobras's offshore operations while maintaining visual sophistication. The aesthetic aligns with the scale and complexity of the B.V. entity ecosystem.

### Design Movement
**Cyberpunk Infrastructure + Data Visualization**
Inspired by sci-fi interfaces, network topology diagrams, and industrial control systems. Think: Bloomberg terminals meets Blade Runner's neon-soaked networks.

### Core Principles
1. **Luminescence Over Flatness** – Nodes emit soft glows; edges carry visual energy through gradients and animations
2. **Hierarchy Through Darkness** – Dark background amplifies node prominence; strategic use of accent colors guides attention
3. **Responsive Geometry** – Nodes scale and pulse based on entity relationships; visual weight reflects importance
4. **Precision in Motion** – Smooth, purposeful animations; no frivolous movement

### Color Philosophy
- **Primary Background:** Deep navy-black (`oklch(0.08 0.01 265)`) – evokes offshore night operations
- **Node Base:** Slate blue (`oklch(0.45 0.15 265)`) with glow effects
- **Petrobras-linked Entities:** Warm amber/gold (`oklch(0.65 0.18 50)`) – corporate identity
- **Upstream/Offshore Vehicles:** Cyan/electric blue (`oklch(0.55 0.20 200)`) – operational assets
- **Vendor/Service Providers:** Muted purple (`oklch(0.50 0.12 280)`) – supporting ecosystem
- **Accent Highlights:** Neon green (`oklch(0.70 0.25 140)`) for hover/selection states

### Layout Paradigm
**Force-Directed Graph with Orbital Clustering**
- Petrobras-linked entities occupy the center (gravitational core)
- Upstream/offshore vehicles orbit in concentric rings by asset type
- Vendors cluster in outer regions by service category
- Edges show contractual/operational relationships with varying opacity and color

### Signature Elements
1. **Glowing Node Halos** – Each node has a soft, animated glow that intensifies on hover
2. **Pulsing Edge Flows** – Edges animate with flowing particles to indicate data/relationship flow
3. **Data Badges** – Small KVK number and address labels that appear on node selection

### Interaction Philosophy
- **Hover:** Node glows intensify; connected edges highlight; tooltip shows entity name
- **Click:** Detail panel slides in from the right; node locks its glow state
- **Search/Filter:** Nodes fade/brighten based on relevance; edges adjust opacity to show filtered relationships
- **Drag:** Nodes can be repositioned; physics simulation smoothly adjusts layout

### Animation
- **Node Entrance:** Scale from 0.8 to 1.0 with opacity fade-in (300ms ease-out)
- **Glow Pulse:** Continuous subtle pulse (2s infinite) that intensifies on interaction
- **Edge Flow:** Animated dashes flowing along edges (4s linear loop)
- **Panel Slide:** Detail panel enters from right with 250ms ease-out; backdrop blur fades in
- **Hover Highlight:** Connected nodes brighten (150ms ease-out); unrelated nodes dim slightly

### Typography System
- **Display Font:** IBM Plex Mono Bold – technical, authoritative, monospace feel
- **Body Font:** Inter Regular – clean readability for KVK data and descriptions
- **Hierarchy:** 
  - Entity names: 16px IBM Plex Mono Bold (uppercase for Petrobras entities)
  - KVK numbers: 12px IBM Plex Mono Regular, muted color
  - Detail panel headers: 18px IBM Plex Mono Bold
  - Descriptions: 13px Inter Regular

### Brand Essence
**Petrobras's offshore B.V. universe mapped as a living network of industrial precision and operational complexity.**
- **Positioning:** For researchers, analysts, and stakeholders studying Petrobras's corporate structure
- **Why Different:** Interactive, data-driven, visually sophisticated—not a static org chart
- **Personality:** Technical, authoritative, exploratory, data-forward

### Brand Voice
- **Headlines:** Direct, technical, data-focused
- **CTAs:** Action-oriented ("Explore Entity," "View Details," "Filter by Category")
- **Microcopy:** Precise, avoiding jargon where possible
- **Example Lines:**
  - "Trace the Petrobras offshore ecosystem through 67 interconnected B.V. entities"
  - "Click any node to reveal KVK registration details and operational relationships"

### Wordmark & Logo
A stylized **network node icon** – a central circle with radiating connection points, rendered in neon cyan with a subtle glow effect. Clean, geometric, instantly recognizable as a network/relationship symbol. No text; pure symbol.

### Signature Brand Color
**Neon Cyan** (`oklch(0.55 0.20 200)`) – evokes offshore operations, data networks, and technical precision. Unmistakably associated with this project.

---

## Implementation Commitment
This design will be applied consistently across:
- Node styling and glow effects
- Edge animations and color coding
- Detail panel layout and typography
- Search/filter UI and interactions
- Color palette in Tailwind configuration
- Animation timing and easing throughout
